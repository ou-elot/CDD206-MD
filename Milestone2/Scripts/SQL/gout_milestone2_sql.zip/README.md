# Milestone 2 SQL

This folder contains the SQL that was retained/reconstructed from the completed analysis.

Files:
- `final_note_subset.sql` — creates the final 13,481-note / 4,985-patient NLP subset.
- `demographics.sql` — creates demographics for the 4,985 NLP-analysis patients.
- `structured_allopurinol.sql` — creates the structured allopurinol treatment indicator for the same patients.
- `verify_structured_allopurinol.sql` — verifies the structured treatment counts.

Important:
The original full clinical-note extraction query that created `eou.gout_extracted_notes`
was not retained exactly. Do not claim that this folder reproduces that initial extraction step.
These files reproduce the downstream processing from the existing extracted-note table onward.
